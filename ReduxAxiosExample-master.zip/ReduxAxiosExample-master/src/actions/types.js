export const ADD_POST = 'ADD_POST';
export const DELETE_POST = 'DELETE_POST';

export const FETCH_POST = 'FETCH_POST';